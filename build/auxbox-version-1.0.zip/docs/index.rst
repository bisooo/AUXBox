" AuxBox's Documentation "
==================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   events/business/BusinessLayer
   events/data/DataLayer
   events/presentation/PresentationLayer


INDEX
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
