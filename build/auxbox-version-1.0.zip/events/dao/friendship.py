from events.dao.base import BaseDao
from django.db import models
from events.models import Friendship
from django.utils import timezone
import datetime
from events.daointerface.eventinterface import EventDaoInterface
from django.db.models import Q


class FriendshipDao:
    model = Friendship

    def get_friendships(self):
        return self.model.objects.all()

    def get_accepted_friendships(self, user):
        return self.model.objects.filter(Q(state=1, requester=user) | Q(state=1, receiver=user))

    def get_rejected_friendships(self, user):
        return self.model.objects.filter(Q(state=0, requester=user) | Q(state=0, receiver=user))
