from events.daointerface.baseinterface import BaseDaoInterface
from events.models.request import Request


class RequestDaoInterface(BaseDaoInterface):

    model = Request
