from events.factory.DAOFactory import DaoFactory
from django.db import InternalError


class InvitationResponseService:

    @staticmethod
    def accept_invitation(from_user, to_user, event):
        DaoFactory.getInvitationDao().accept_invitation(from_user, to_user, event)
        if not DaoFactory.getInvitationDao().check_invitation(from_user, to_user, event, 1):
            raise InternalError('invitation could not be accepted and participation could not '
                                'be created')
        DaoFactory.getParticipationDao().create_participation(to_user, event)
        if not DaoFactory.getParticipationDao().check_participation(event.id, to_user.id):
            raise InternalError('invitation could not be accepted and participation could not '
                                'be created')

    @staticmethod
    def reject_invitation(from_user, to_user, event):
        DaoFactory.getInvitationDao().reject_invitation(from_user, to_user, event)
        if not DaoFactory.getInvitationDao().check_invitation(from_user, to_user, event, 0):
            raise InternalError('invitation could not be rejected and invitation state could '
                                'not be adjusted to 0')
