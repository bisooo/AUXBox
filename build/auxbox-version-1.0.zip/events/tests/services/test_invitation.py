from django.db import IntegrityError
from events.services.invitation import InvitationService
from events.tests import BaseTestCase


class InvitationTestCase(BaseTestCase):

    def test_existing_user_invitation(self):
        with self.assertRaisesMessage(IntegrityError, "Invitation Already Exists"):
            InvitationService().register_invitation(self.user, self.user2, self.event2.id)

    def test_existing_user(self):
        with self.assertRaisesMessage(IntegrityError, "User Already Joined The Event"):
            InvitationService().register_invitation(self.user, self.user3, self.event2.id)
