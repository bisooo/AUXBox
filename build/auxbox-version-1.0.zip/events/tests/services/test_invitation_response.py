from events.services.invitationresponse import InvitationResponseService
from events.tests import BaseTestCase
from django.db import InternalError


class InvitationResponseTest(BaseTestCase):

    def test_should_accept_invitation(self):
        with self.assertRaisesMessage(InternalError, 'invitation could not be accepted and participation could not '
                                                     'be created'):
            InvitationResponseService().accept_invitation(self.mock_from_user, self.mock_to_user, self.mock_event)

    def test_should_reject_invitation(self):
        with self.assertRaisesMessage(InternalError, 'invitation could not be rejected and invitation state could '
                                                     'not be adjusted to 0'):
            InvitationResponseService().reject_invitation(self.mock_from_user, self.mock_to_user, self.mock_event)
