from events.tests import BaseTestCase


class UserTestCase(BaseTestCase):

    pass
