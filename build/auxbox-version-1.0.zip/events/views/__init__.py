from events.views import homepage
from events.views import create_event
from events.views import view_event
from events.views import add_friend
from events.views import user_search
from events.views import aboutpage
from events.views import show_invitations

