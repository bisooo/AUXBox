from django.shortcuts import render

from events.factory.DAOFactory import DaoFactory
from events.services.invitation import InvitationService
from events.services.spotifyHandler import SpotifyHandler
from events.views.landing import landing
from events.services.invitationresponse import InvitationResponseService


def invitation_response(request, event_id: int, from_user_id: int, to_user_id: int, response: int):
    sp = SpotifyHandler()
    user = sp.check_user_authentication(request)

    if not user:
        return landing(request)

    if response == 1:
        print("annen")
        InvitationResponseService.accept_invitation(from_user=DaoFactory.getUserDao().get_by_id(from_user_id),
                                                    to_user=DaoFactory.getUserDao().get_by_id(to_user_id),
                                                    event=DaoFactory.getEventDao().find_by_id(event_id))

    if response == 0:
        InvitationResponseService.reject_invitation(from_user=DaoFactory.getUserDao().get_by_id(from_user_id),
                                                    to_user=DaoFactory.getUserDao().get_by_id(to_user_id),
                                                    event=DaoFactory.getEventDao().find_by_id(event_id))

    invitations = InvitationService.get_users_pending_invitations(user=user)

    return render(request, 'invites.html', {'invitations': invitations})
