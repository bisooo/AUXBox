from django.shortcuts import render

from events.dao.invitation import InvitationDao
from events.services.spotifyHandler import SpotifyHandler


def show_invitations(request):
    user = SpotifyHandler.check_user_authentication(request)
    invitations = InvitationDao().get_invitations(user=user)

    return render(request, 'invitations.html', {'invitation': invitations})
